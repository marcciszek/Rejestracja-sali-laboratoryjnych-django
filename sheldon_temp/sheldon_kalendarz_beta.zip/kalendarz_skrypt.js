function isLeapYear(year)
{
	return (year%4==0 && year%100!=0) ||  (year%400 == 0)
}

function generateCalendarCells(month,year)
{
	const monthLengths = [31,28,31,30,31,30,31,31,30,31,30,31];
	if (isLeapYear(year)) monthLengths[1] = 29;
	const firstDay = new Date(year,month,1);
	const firstWeekday = firstDay.getDay();
	const calendarCells = [...document.querySelectorAll('.calendar-cell')];
	let count = 0;
	let dayCount = 1;
	calendarCells.forEach((cell)=>{
		if (count>=firstWeekday && count<firstWeekday+monthLengths[month])
		{
			cell.innerText = dayCount;
			cell.classList.add('calendar-cell-active');
			cell.classList.remove('calendar-cell-inactive');
			dayCount++;
		}
		else
		{
			cell.innerText = '';
			cell.classList.add('calendar-cell-inactive');
			cell.classList.remove('calendar-cell-active');
		}
		count++;
	});
}

function run()
{
	const month_input = document.getElementById('month-input');
	const year_input = document.getElementById('year-input');
	generateCalendarCells(month_input.value,year_input.value);
	month_input.addEventListener('input',function()
	{
		generateCalendarCells(month_input.value,year_input.value);
	});
	year_input.addEventListener('input',function()
	{
		generateCalendarCells(month_input.value,year_input.value);
	});	
}

document.addEventListener('DOMContentLoaded',run);